const Logger = require("./logger");

const logger = new Logger();


module.exports = {
    logger
    };