import { hookstate, useHookstate } from '@hookstate/core';
export default {
    global_step_state: hookstate({})
}